import Head from "next/head";
import Image from "next/image";
import { FC } from "react";

import logo from '@/assets/logo.png';
import { useIsPc } from "@/hooks/useIsPc";

const HomePage: FC = () => {
  const isPc = useIsPc();
  return (
    <>
      <Head>
        <title>

        </title>
      </Head>
      <main
        className="w-full h-full flex flex-col justify-center items-center"
      >
        <div className="relative w-full h-[300px] intro">
          <h1
            className={`title-main absolute w-fit h-fit ${isPc
              ? ''
              : 'text-[2rem]'}`}
          >
            ИНСАЙТИФАЙ
          </h1>
          <p className="absolute w-fit h-fit title-secondary">
            УНИКАЛЬНЫЕ МЕТОДЫ <br />
            РЕЗУЛЬТАТИВНЫЕ ГАЙДЫ <br />
            РЕШЕНИЕ ПРОБЛЕМ <br />
            ...И САМОЕ ГЛАВНОЕ - <br />
            ИНСАЙТЫ
          </p>
        </div>
        <Image
          src={logo}
          alt="Logo image"
          className="w-auto h-[310px]"
        />
      </main>
    </>
  )
}

export default HomePage;