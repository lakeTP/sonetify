import Head from "next/head";
import Image from "next/image";
import { FC } from "react";

import puzzle1 from '@/assets/puzzles/несправедливость.png';
import puzzle2 from '@/assets/puzzles/отвергнутость.png';
import puzzle3 from '@/assets/puzzles/покинутость.png';
import puzzle4 from '@/assets/puzzles/предательство.png';
import puzzle5 from '@/assets/puzzles/униженность.png';
import { Styled } from "@/styled";
import styles from './styles.module.css';
import { useIsPc } from "@/hooks/useIsPc";

const GuidesPage: FC = () => {
  const isPc = useIsPc();
  return (
    <>
      <Head>
        <title>
          добро пожаловать
        </title>
        <style>
          {isPc
            ? `
              html {
                // min-width:100vw;
                // min-height:100vh;
              }
            `
            : `
            `}
        </style>
      </Head>
      <main className={`flex flex-col w-full h-full justify-start items-center`}>
        {isPc
          ? <>
            <div className="intro relative w-full h-[192px] mb-[50px]">
              <h1 className="title-main w-full absolute text-[7rem]">
                ПРОЕКТ ТРАВМЫ
              </h1>
              <h2 className="title-secondary w-fit absolute bottom-[20px]">
                ЧТО ЗА ТРАВМЫ <br />
                И С ЧЕМ ИХ ЕДЯТ?
              </h2>
            </div>
            <div className="w-[80%] anonymous text-center tracking-[1px] text-[1.3rem]">
              <p>
                БОЛЬШИНСТВО ТРАВМ МЫ ПОЛУЧАЕМ В ДЕТСКОМ ВОЗРАСТЕ, ИМЕННО ПОЭТОМУ ПРИЧИНОЙ ТРАВМЫ МОГУТ <br />
                СТАТЬ НЕЗНАЧИТЕЛЬНЫЕ ВЕЩИ. К ПРИМЕРУ, РЕЗКИЕ ВЫСКАЗЫВАНИЯ РОДИТЕЛЕЙ, КОТОРЫЕ ДАЖЕ СТАЛИ <br />
                «КРЫЛАТЫМИ» В НАШЕМ ОБЩЕСТВЕ. <br />
              </p>
              <p>
                К СЛОВУ, У КАЖДОГО ЧЕЛОВЕКА ЕСТЬ КАК МИНИМУМ 3 ТРАВМЫ, А ЧАСТО И ВСЕ 5, НО ОНИ ИМЕЮТ <br />
                РАЗНУЮ ВЫРАЖЕННОСТЬ. Я РЕКОМЕНДУЮ ВАМ ОЗНАКОМИТЬСЯ С ОПИСАНИЕМ КАЖДОЙ ТРАВМЫ, О ПРИЧИНАХ  <br />
                ЕЕ ВОЗНИКНОВЕНИЯ И СПОСОБАМИ РЕШЕНИЯ. <br />
              </p>
              <p>
                ПРИОБРЕТАЯ ТРАВМУ, ЧЕЛОВЕК ПОДСОЗНАТЕЛЬНО ВЫРАБАТЫВАЕТ ТАКОЙ ПАТТЕРН ПОВЕДЕНИЯ, КОТОРЫЙ <br />
                (ПО ЕГО МНЕНИЮ) В БУДУЩЕМ ПОМОЖЕТ ИЗБЕЖАТЬ ПОВТОРЕНИЯ ПОХОЖЕЙ СИТУАЦИИ. ТОЛЬКО ПАРАДОКС <br />
                В ТОМ, ЧТО ТАКИЕ ПАТТЕРНЫ ПОВЕДЕНИЯ НЕ ЗАЩИЩАЮТ ОТ ПОВТОРА СЦЕНАРИЯ, А НАОБОРОТ, <br /> ПРИТЯГИВАЮТ ЕГО И С КАЖДЫМ РАЗОМ УСИЛИВАЮТ ГЛУБИНУ ТРАВМЫ. КАК СЛЕДСТВИЕ, УХУДШАЕТСЯ <br /> ПСИХИЧЕСКОЕ СОСТОЯНИЕ И ОБЩЕЕ КАЧЕСТВО ЖИЗНИ, А ДЛИТЕЛЬНОЕ ИГНОРИРОВАНИЕ СВОЕГО <br /> СОСТОЯНИЯ МОЖЕТ ПРИВЕСТИ К НЕРВНЫМ СРЫВАМ И ДЕПРЕССИЯМ. <br />
                НУ И КОМУ ЭТО НАДО, ДЕВОЧКИ?
              </p>
              <Styled.Button
                className={`w-[150px] h-[60px] mt-[20px] 
            text-[0.9rem] p-[0.4rem]  ${isPc
                    ? 'h-[80px] text-[1.2rem]  w-[210px]'
                    : ''}`}
              >
                ПРОЙТИ ТЕСТ
                <br />
                1 ШАГ
              </Styled.Button>
            </div>
            <div className="absolute overflow-hidden top-0 left-0 w-full h-full z-[-5]">
              <Image
                src={puzzle1}
                alt={"Несправедливость"}
                className="w-[450px] h-auto absolute top-[220px] z-[-1] right-[-150px] rotate-[-30deg]"
              />
              <Image
                src={puzzle2}
                alt={"Отвергнутость"}
                className="w-[450px] h-auto absolute top-[454px] left-[-125px]"
              />
              <Image
                src={puzzle3}
                alt={"Покинутость"}
                className="w-[450px] h-auto absolute bottom-[-140px] left-[70px]"
              />
              <Image
                src={puzzle4}
                alt={"Предательство"}
                className="w-[450px] h-auto absolute left-[-97px] top-[140px] z-[-2] rotate-[15deg]"
              />
              <Image
                src={puzzle5}
                alt={"Униженность"}
                className="w-[450px] h-auto absolute bottom-[-70px] right-[-70px] rotate-[25deg]"
              />
            </div>
          </>
          : <>
            <div className="relative w-full h-full z-[-5] overflow-x-clip">
              <h1 className={`absolute mx-auto intro inset-0 mt-[250px] w-fit h-fit mb-[140px] ${isPc
                ? 'text-[3rem]'
                : 'text-[1.5rem]'
                }`}>
                ИНСАЙТИФАЙ
              </h1>
              <Image
                src={puzzle1}
                alt={"Несправедливость"}
                className="w-[280px] h-auto absolute top-[50px] left-[5px] z-[-1]"
              />
              <Image
                src={puzzle2}
                alt={"Отвергнутость"}
                className="w-[280px] h-auto absolute top-[224px] left-[-65px]"
              />
              <Image
                src={puzzle3}
                alt={"Покинутость"}
                className="w-[280px] h-auto absolute top-[168px] right-[-75px]"
              />
              <Image
                src={puzzle4}
                alt={"Предательство"}
                className="w-[280px] h-auto absolute left-[-77px] top-[-48px] z-[-2]"
              />
              <Image
                src={puzzle5}
                alt={"Униженность"}
                className="w-[280px] h-auto absolute top-[-20px] right-[-64px]"
              />
            </div>
            <div className={`${styles['HomePage__main-content']} w-full h-full flex flex-col justify-between items-center `}>
              <div className="flex flex-col justify-center items-center gap-[10px]">
                <h2 className={`${isPc
                  ? 'text-[1.9rem]'
                  : "text-[1.7rem]"} `}>
                  добро пожаловать
                </h2>
                <p className={`w-full text-center ${isPc ? 'text-[1.5rem]' : "text-[1.1rem]"}`}>
                  Ваша доставка инсайтов для пошагового <br />
                  решения крайне важных проблем, <br />
                  полученных из травм детства. <br />
                  О них мало кто говорит, но эти травмы <br />
                  касаются каждого ежедневно и мешают <br />
                  полноценной жизни. <br />
                </p>
              </div>
              <Styled.Button
                className={`w-[150px] h-[60px] 
            text-[0.9rem] p-[0.4rem]  ${isPc
                    ? 'h-[80px] text-[1.2rem] mb-[60px] w-[210px]'
                    : 'mb-[10px]'}`}
              >
                ПРОЙТИ ТЕСТ
                <br />
                1 ШАГ
              </Styled.Button>
            </div>
          </>
        }
      </main >
    </>
  )
}

export default GuidesPage;