import Head from "next/head";
import { FC } from "react";

const ConsultationsPage: FC = () => {
  return (
    <>
      <Head>
        <title>

        </title>
      </Head>
      <main
        className="w-full h-full"
      >

      </main>
    </>
  )
}

export default ConsultationsPage;