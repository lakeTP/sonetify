import Image from "next/image";
import { FC } from "react";

import Navbar from "./Navbar/Navbar";
import { NavbarLinkProps } from "./Navbar/NavbarLink/models";
import logoImage from '@/assets/logo.png';

const links: NavbarLinkProps[] = [
  {
    href: '/',
    text: 'ГЛАВНАЯ',
  },
  {
    href: '/about',
    text: 'О @SONETIFY',
  },
  {
    href: '/guides',
    text: 'ГАЙДЫ',
  },
  {
    href: '/consultations',
    text: 'КОНСУЛЬТАЦИИ',
  },
]

const Header: FC = () => {
  return (
    <header
      className="flex justify-between px-5 w-full items-center h-fit"
    >
      <Image
        src={logoImage}
        className="w-auto h-[120px]"
        alt='Logo image'
      />
      <Navbar links={links} />
    </header>
  )
}

export default Header