import { NavbarLinkProps } from "./NavbarLink/models";

export type NavbarProps = {
  links: NavbarLinkProps[];
};
