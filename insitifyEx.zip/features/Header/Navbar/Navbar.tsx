import { useRouter } from "next/router";
import { FC, useEffect } from "react";

import { useSelectedLink } from "@/hooks/useSelectedLink";
import { NavbarProps } from "./models";
import NavbarLink from "./NavbarLink/NavbarLink";

const Navbar: FC<NavbarProps> = ({ links }) => {
  const { setSelectedLink } = useSelectedLink();
  const router = useRouter();
  useEffect(() => {
    setSelectedLink(router.asPath);
  }, [])
  return (
    <nav className="flex">
      <ul className="flex gap-[30px] pr-5">
        {links.map((linkProps) => (
          <li key={linkProps.text} className="flex">
            <NavbarLink {...linkProps} />
          </li>
        ))}
      </ul>
    </nav>
  )
}

export default Navbar;