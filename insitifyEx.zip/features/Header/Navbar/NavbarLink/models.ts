export type NavbarLinkProps = {
  href: string;
  text: string;
};
