import { Button } from "./Button/Button";

export const Styled = {
  Button,
};
